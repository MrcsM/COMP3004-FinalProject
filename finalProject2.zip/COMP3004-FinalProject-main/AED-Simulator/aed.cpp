#include "aed.h"

AED::AED()
{

}
