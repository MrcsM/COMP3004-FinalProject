#ifndef AED_H
#define AED_H


class AED
{
public:
    AED();
};

#endif // AED_H
