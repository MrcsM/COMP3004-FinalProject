# COMP3004-FinalProject
AED Simulator for COMP3004: Object-Oriented Software Engineering

Group:
- Marcus Moquin
- Jared Best
- Matthew Parsons
- Alejandro Ferreira

note for group:
- please use branches & pr's when makin changes so we don't clog each other 
